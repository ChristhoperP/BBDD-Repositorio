DELETE FROM Hechos_Boletos;
DELETE FROM Dimension_Pais_Destino;
DELETE FROM Dimension_Pais_Origen;
DELETE FROM Dimension_Tiempo;
DELETE FROM Dimension_Empleado;
DELETE FROM Dimension_Clase;

select * FROM Hechos_Boletos;
select * FROM Dimension_Pais_Destino;
select * FROM Dimension_Pais_Origen;
select * FROM Dimension_Tiempo;
select * FROM Dimension_Empleado;
select * FROM Dimension_Clase;